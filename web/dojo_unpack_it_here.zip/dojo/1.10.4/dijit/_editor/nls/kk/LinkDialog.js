//>>built
define("dijit/_editor/nls/kk/LinkDialog",({createLinkTitle:"Сілтеме сипаттары",insertImageTitle:"Сурет сипаттары",url:"URL:",text:"Сипаттама:",target:"Мақсат:",set:"Орнату",currentWindow:"Ағымдағы терезе",parentWindow:"Басты терезе",topWindow:"Ең жоғарғы терезе",newWindow:"Жаңа терезе"}));
